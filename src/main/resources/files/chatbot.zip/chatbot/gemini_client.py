import google.generativeai as genai
from typing import Dict, Any
import json
from config import config
from tools import TelDevTools, TOOL_DEFINITIONS

class GeminiChatbot:
    """Cliente para Google AI Gemini con Function Calling"""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        genai.configure(api_key=api_key)
        print(f"✅ Google AI configurado")
        
        self.teldev_tools = TelDevTools()
        
        try:
            self.model = genai.GenerativeModel(
                model_name='gemini-2.0-flash-exp'
            )
            print(f"✅ Modelo Gemini 2.0 Flash Experimental cargado")
        except Exception as e:
            print(f"⚠️ Error cargando modelo: {e}")
            raise
    
    def send_message(self, user_message: str, user_id: int) -> Dict[str, Any]:
        """Enviar mensaje al chatbot"""
        print(f"📩 Mensaje: {user_message[:50]}... (User: {user_id})")
        
        try:
            chat = self.model.start_chat()
            
            # Mensaje con contexto - incluimos información del userId
            full_message = f"""{config.SYSTEM_PROMPT}

[Usuario ID: {user_id}]
Usuario: {user_message}

Asistente TelDev:"""
            
            # Enviar mensaje
            response = chat.send_message(full_message)
            response_text = response.text
            
            print(f"✅ Respuesta: {len(response_text)} chars")
            
            return {
                "success": True,
                "response": response_text
            }
        
        except Exception as e:
            error_msg = str(e)
            print(f"❌ Error: {error_msg}")
            return {
                "success": False,
                "error": error_msg,
                "response": "Lo siento, hubo un error al procesar tu mensaje. Por favor, intenta de nuevo."
            }
