# 🤖 CONFIGURACIÓN DE ENDPOINTS PARA CHATBOT FLOWISE - TelDev
**Fecha:** 5 de Noviembre, 2025  
**URL Base del Proyecto:** `https://teldev.pro`  
**Versión:** 1.0

---

## 📋 TABLA DE CONTENIDOS

1. [Información General](#información-general)
2. [Endpoints Críticos del Chatbot](#endpoints-críticos-del-chatbot)
3. [Configuración por Herramienta en Flowise](#configuración-por-herramienta-en-flowise)
4. [Ejemplos de Código para Flowise](#ejemplos-de-código-para-flowise)
5. [Headers de Autenticación](#headers-de-autenticación)
6. [Endpoints Completos por Categoría](#endpoints-completos-por-categoría)

---

## 📌 Información General

### URL Base del Proyecto
```
https://teldev.pro
```

### Prefijos de API
- **Chatbot:** `/api/chatbot`
- **Tickets:** `/api/tickets`
- **Usuario:** `/devportal/user`
- **Documentación:** `/devportal/documentations`
- **Archivos (Repositorios):** `/api/repositories`
- **Archivos (Proyectos):** `/api/projects`

---

## 🔴 Endpoints Críticos del Chatbot

Estos son los endpoints más importantes que debes configurar en Flowise para obtener información del usuario:

### 1. **Obtener Sesión Completa del Usuario** ⭐ MÁS IMPORTANTE
```
GET https://teldev.pro/api/chatbot/session?userId={userId}
```
**Descripción:** Retorna toda la información del usuario incluyendo proyectos, repositorios, APIs, tickets y estadísticas.

**Cuándo usarlo:** Al inicio de la conversación o cuando necesites información completa del usuario.

---

### 2. **Listar Proyectos del Usuario**
```
GET https://teldev.pro/api/chatbot/projects/user/{userId}
```
**Descripción:** Lista todos los proyectos donde el usuario participa (como propietario o miembro).

**Cuándo usarlo:** Cuando el usuario pregunte sobre sus proyectos.

---

### 3. **Listar Repositorios del Usuario**
```
GET https://teldev.pro/api/chatbot/repositories/user/{userId}
```
**Descripción:** Lista todos los repositorios del usuario.

**Cuándo usarlo:** Cuando el usuario pregunte sobre repositorios o código.

---

### 4. **Listar APIs del Usuario**
```
GET https://teldev.pro/api/chatbot/apis/user/{userId}
```
**Descripción:** Lista todas las APIs creadas o gestionadas por el usuario.

**Cuándo usarlo:** Cuando el usuario pregunte sobre APIs o documentación.

---

### 5. **Listar Tickets del Usuario**
```
GET https://teldev.pro/api/chatbot/tickets/user/{userId}
```
**Descripción:** Lista tickets reportados o asignados al usuario.

**Cuándo usarlo:** Cuando el usuario pregunte sobre tickets, bugs o tareas.

---

## 🛠️ Configuración por Herramienta en Flowise

### 🔧 Herramienta 1: Obtener Sesión de Usuario

**Nombre de la Herramienta:** `getUserSession`

**Descripción para Flowise:**
```
Obtiene información completa del usuario incluyendo proyectos, repositorios, APIs, tickets y estadísticas.
```

**Código para Custom Tool en Flowise:**
```javascript
const fetch = require('node-fetch');

const userId = $vars.userId; // Variable pasada desde el frontend

if (!userId) {
    return JSON.stringify({ error: "Usuario no autenticado" });
}

try {
    const response = await fetch(`https://teldev.pro/api/chatbot/session?userId=${userId}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + $vars.authToken // Si usas JWT
        }
    });
    
    const data = await response.json();
    
    if (!response.ok) {
        return JSON.stringify({ error: data.message || 'Error al obtener sesión' });
    }
    
    return JSON.stringify(data, null, 2);
} catch (error) {
    return JSON.stringify({ error: error.message });
}
```

**Respuesta Esperada:**
```json
{
  "success": true,
  "usuario": {
    "usuarioId": 38,
    "username": "mlopez",
    "nombreCompleto": "Miguel Lopez Garcia",
    "correo": "mlopez@example.com",
    "estadoUsuario": "HABILITADO"
  },
  "proyectos": [
    {
      "proyectoId": 5,
      "nombre": "Sistema de Pagos",
      "descripcion": "API de procesamiento de pagos",
      "tipoProyecto": "PERSONAL",
      "estadoProyecto": "ACTIVO"
    }
  ],
  "repositorios": [...],
  "apis": [...],
  "tickets": [...],
  "estadisticas": {
    "totalProyectos": 5,
    "totalRepositorios": 12,
    "totalApis": 3,
    "ticketsPendientes": 2,
    "totalTickets": 8
  }
}
```

---

### 🔧 Herramienta 2: Listar Proyectos

**Nombre de la Herramienta:** `getUserProjects`

**Descripción para Flowise:**
```
Lista todos los proyectos del usuario.
```

**Código para Custom Tool en Flowise:**
```javascript
const fetch = require('node-fetch');

const userId = $vars.userId;

if (!userId) {
    return JSON.stringify({ error: "Usuario no autenticado" });
}

try {
    const response = await fetch(`https://teldev.pro/api/chatbot/projects/user/${userId}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + $vars.authToken
        }
    });
    
    const data = await response.json();
    
    if (!response.ok) {
        return JSON.stringify({ error: data.message || 'Error al obtener proyectos' });
    }
    
    return JSON.stringify(data, null, 2);
} catch (error) {
    return JSON.stringify({ error: error.message });
}
```

---

### 🔧 Herramienta 3: Listar Repositorios

**Nombre de la Herramienta:** `getUserRepositories`

**Descripción para Flowise:**
```
Lista todos los repositorios del usuario.
```

**Código para Custom Tool en Flowise:**
```javascript
const fetch = require('node-fetch');

const userId = $vars.userId;

if (!userId) {
    return JSON.stringify({ error: "Usuario no autenticado" });
}

try {
    const response = await fetch(`https://teldev.pro/api/chatbot/repositories/user/${userId}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + $vars.authToken
        }
    });
    
    const data = await response.json();
    
    if (!response.ok) {
        return JSON.stringify({ error: data.message || 'Error al obtener repositorios' });
    }
    
    return JSON.stringify(data, null, 2);
} catch (error) {
    return JSON.stringify({ error: error.message });
}
```

---

### 🔧 Herramienta 4: Listar APIs

**Nombre de la Herramienta:** `getUserApis`

**Descripción para Flowise:**
```
Lista todas las APIs del usuario.
```

**Código para Custom Tool en Flowise:**
```javascript
const fetch = require('node-fetch');

const userId = $vars.userId;

if (!userId) {
    return JSON.stringify({ error: "Usuario no autenticado" });
}

try {
    const response = await fetch(`https://teldev.pro/api/chatbot/apis/user/${userId}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + $vars.authToken
        }
    });
    
    const data = await response.json();
    
    if (!response.ok) {
        return JSON.stringify({ error: data.message || 'Error al obtener APIs' });
    }
    
    return JSON.stringify(data, null, 2);
} catch (error) {
    return JSON.stringify({ error: error.message });
}
```

---

### 🔧 Herramienta 5: Listar Tickets

**Nombre de la Herramienta:** `getUserTickets`

**Descripción para Flowise:**
```
Lista todos los tickets del usuario (reportados y asignados).
```

**Código para Custom Tool en Flowise:**
```javascript
const fetch = require('node-fetch');

const userId = $vars.userId;

if (!userId) {
    return JSON.stringify({ error: "Usuario no autenticado" });
}

try {
    const response = await fetch(`https://teldev.pro/api/chatbot/tickets/user/${userId}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + $vars.authToken
        }
    });
    
    const data = await response.json();
    
    if (!response.ok) {
        return JSON.stringify({ error: data.message || 'Error al obtener tickets' });
    }
    
    return JSON.stringify(data, null, 2);
} catch (error) {
    return JSON.stringify({ error: error.message });
}
```

---

### 🔧 Herramienta 6: Crear Ticket

**Nombre de la Herramienta:** `createTicket`

**Descripción para Flowise:**
```
Crea un nuevo ticket de soporte o bug.
```

**Código para Custom Tool en Flowise:**
```javascript
const fetch = require('node-fetch');

const userId = $vars.userId;
const asunto = $input.asunto; // Pasado desde el prompt del LLM
const cuerpo = $input.cuerpo;
const prioridad = $input.prioridad || 'MEDIA'; // BAJA, MEDIA, ALTA, CRITICA
const tipo = $input.tipo || 'SOPORTE'; // BUG, FEATURE, MEJORA, DOCUMENTACION, SOPORTE

if (!userId) {
    return JSON.stringify({ error: "Usuario no autenticado" });
}

if (!asunto || !cuerpo) {
    return JSON.stringify({ error: "Debe proporcionar asunto y descripción del ticket" });
}

try {
    const response = await fetch(`https://teldev.pro/api/tickets`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + $vars.authToken
        },
        body: JSON.stringify({
            asunto: asunto,
            cuerpo: cuerpo,
            prioridad: prioridad,
            tipo: tipo,
            reportadoPorId: userId
        })
    });
    
    const data = await response.json();
    
    if (!response.ok) {
        return JSON.stringify({ error: data.message || 'Error al crear ticket' });
    }
    
    return JSON.stringify({ 
        success: true, 
        message: "Ticket creado exitosamente",
        ticketId: data.ticketId,
        codigoTicket: data.codigoTicket
    }, null, 2);
} catch (error) {
    return JSON.stringify({ error: error.message });
}
```

---

### 🔧 Herramienta 7: Crear Conversación

**Nombre de la Herramienta:** `createConversation`

**Descripción para Flowise:**
```
Guarda la conversación actual en la base de datos.
```

**Código para Custom Tool en Flowise:**
```javascript
const fetch = require('node-fetch');

const userId = $vars.userId;
const titulo = $input.titulo || 'Conversación del chatbot';
const mensajeInicial = $input.mensajeInicial;
const tema = $input.tema || 'GENERAL'; // GENERAL, PROYECTO, TICKET, API, REPOSITORIO

if (!userId || !mensajeInicial) {
    return JSON.stringify({ error: "Faltan datos requeridos" });
}

try {
    const response = await fetch(`https://teldev.pro/api/chatbot/conversations`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + $vars.authToken
        },
        body: JSON.stringify({
            usuarioId: userId,
            titulo: titulo,
            mensajeInicial: mensajeInicial,
            tema: tema,
            estado: 'ACTIVA'
        })
    });
    
    const data = await response.json();
    
    if (!response.ok) {
        return JSON.stringify({ error: data.message || 'Error al crear conversación' });
    }
    
    return JSON.stringify({ 
        success: true, 
        conversacionId: data.conversacionId,
        message: "Conversación guardada"
    }, null, 2);
} catch (error) {
    return JSON.stringify({ error: error.message });
}
```

---

### 🔧 Herramienta 8: Buscar Documentación

**Nombre de la Herramienta:** `searchDocumentation`

**Descripción para Flowise:**
```
Busca en la documentación de las APIs.
```

**Código para Custom Tool en Flowise:**
```javascript
const fetch = require('node-fetch');

const keyword = $input.keyword; // Palabra clave de búsqueda

if (!keyword) {
    return JSON.stringify({ error: "Debe proporcionar una palabra clave para buscar" });
}

try {
    const response = await fetch(`https://teldev.pro/devportal/documentations?search=${encodeURIComponent(keyword)}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + $vars.authToken
        }
    });
    
    const data = await response.json();
    
    if (!response.ok) {
        return JSON.stringify({ error: data.message || 'Error al buscar documentación' });
    }
    
    return JSON.stringify(data, null, 2);
} catch (error) {
    return JSON.stringify({ error: error.message });
}
```

---

## 🔐 Headers de Autenticación

### Opción 1: Session-based (Cookies)
Si tu aplicación usa sesiones, los headers básicos son:
```javascript
headers: {
    'Content-Type': 'application/json',
    'Cookie': document.cookie // Automáticamente incluye cookies de sesión
}
```

### Opción 2: JWT Token
Si implementas JWT:
```javascript
headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + $vars.authToken
}
```

### Configurar Variables en Flowise

En el nodo de inicio del chatflow de Flowise, configura estas variables:
```json
{
  "userId": "{{ USER_ID }}",
  "authToken": "{{ JWT_TOKEN }}",
  "username": "{{ USERNAME }}"
}
```

Estas variables deben pasarse desde tu frontend cuando inicias el chat:
```javascript
// En tu aplicación web
const chatConfig = {
    userId: currentUser.id,
    authToken: localStorage.getItem('jwt_token'),
    username: currentUser.username
};

// Pasar a Flowise al iniciar el chat
flowiseWidget.init({
    chatflowid: 'tu-chatflow-id',
    apiHost: 'https://tu-flowise.com',
    chatflowConfig: chatConfig
});
```

---

## 📊 Endpoints Completos por Categoría

### 🤖 CHATBOT

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `https://teldev.pro/api/chatbot/session?userId={id}` | Sesión completa del usuario |
| GET | `https://teldev.pro/api/chatbot/projects/user/{userId}` | Proyectos del usuario |
| GET | `https://teldev.pro/api/chatbot/repositories/user/{userId}` | Repositorios del usuario |
| GET | `https://teldev.pro/api/chatbot/apis/user/{userId}` | APIs del usuario |
| GET | `https://teldev.pro/api/chatbot/tickets/user/{userId}` | Tickets del usuario |
| POST | `https://teldev.pro/api/chatbot/conversations` | Crear conversación |
| POST | `https://teldev.pro/api/chatbot/conversations/with-context` | Crear conversación con contexto |
| GET | `https://teldev.pro/api/chatbot/conversations/{id}` | Obtener conversación |
| GET | `https://teldev.pro/api/chatbot/conversations/user/{userId}` | Listar conversaciones del usuario |
| PUT | `https://teldev.pro/api/chatbot/conversations/{id}` | Actualizar conversación |
| PUT | `https://teldev.pro/api/chatbot/conversations/{id}/resolve` | Marcar conversación como resuelta |
| PUT | `https://teldev.pro/api/chatbot/conversations/{id}/close` | Cerrar conversación |
| DELETE | `https://teldev.pro/api/chatbot/conversations/{id}` | Eliminar conversación |

---

### 🎫 TICKETS

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `https://teldev.pro/api/tickets` | Crear ticket |
| POST | `https://teldev.pro/api/tickets/public` | Crear ticket público |
| GET | `https://teldev.pro/api/tickets/{id}` | Obtener ticket |
| GET | `https://teldev.pro/api/tickets/user/{userId}` | Tickets del usuario |
| GET | `https://teldev.pro/api/tickets/reported-by/{userId}` | Tickets reportados por usuario |
| GET | `https://teldev.pro/api/tickets/assigned-to/{userId}` | Tickets asignados a usuario |
| GET | `https://teldev.pro/api/tickets/project/{projectId}` | Tickets de un proyecto |
| GET | `https://teldev.pro/api/tickets/status/{status}` | Filtrar por estado |
| GET | `https://teldev.pro/api/tickets/priority/{priority}` | Filtrar por prioridad |
| GET | `https://teldev.pro/api/tickets/open` | Tickets abiertos |
| GET | `https://teldev.pro/api/tickets/closed` | Tickets cerrados |
| PUT | `https://teldev.pro/api/tickets/{id}/assign/{userId}` | Asignar ticket |
| PUT | `https://teldev.pro/api/tickets/{id}/close` | Cerrar ticket |
| PUT | `https://teldev.pro/api/tickets/{id}/resolve` | Resolver ticket |
| DELETE | `https://teldev.pro/api/tickets/{id}` | Eliminar ticket |

**Valores válidos para Tickets:**
- **Estado:** `ABIERTO`, `CERRADO`, `CANCELADO`
- **Etapa:** `PENDIENTE`, `EN_PROGRESO`, `RESUELTO`, `RECHAZADO`
- **Prioridad:** `BAJA`, `MEDIA`, `ALTA`, `CRITICA`
- **Tipo:** `BUG`, `FEATURE`, `MEJORA`, `DOCUMENTACION`, `SOPORTE`

---

### 👤 USUARIO

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `https://teldev.pro/devportal/user` | Listar todos los usuarios |
| GET | `https://teldev.pro/devportal/user/{id}` | Obtener usuario por ID |
| GET | `https://teldev.pro/devportal/user/check-exists?email={email}` | Verificar si usuario existe |
| POST | `https://teldev.pro/devportal/user` | Crear usuario |
| PUT | `https://teldev.pro/devportal/user/{id}` | Actualizar usuario |
| DELETE | `https://teldev.pro/devportal/user/{id}` | Eliminar usuario |

---

### 📚 DOCUMENTACIÓN

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `https://teldev.pro/devportal/documentations` | Listar documentaciones |
| GET | `https://teldev.pro/devportal/documentations/{id}` | Obtener documentación |
| POST | `https://teldev.pro/devportal/documentations` | Crear documentación |
| PUT | `https://teldev.pro/devportal/documentations/{id}` | Actualizar documentación |
| DELETE | `https://teldev.pro/devportal/documentations/{id}` | Eliminar documentación |

---

### 📁 ARCHIVOS (Repositorios)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `https://teldev.pro/api/repositories/{repoId}/files` | Listar archivos raíz |
| GET | `https://teldev.pro/api/repositories/{repoId}/files/{parentId}` | Listar archivos de carpeta |
| POST | `https://teldev.pro/api/repositories/{repoId}/folders` | Crear carpeta |

---

### 📂 ARCHIVOS (Proyectos)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `https://teldev.pro/api/projects/{projectId}/files` | Listar archivos raíz |
| GET | `https://teldev.pro/api/projects/{projectId}/files/{parentId}` | Listar archivos de carpeta |
| POST | `https://teldev.pro/api/projects/{projectId}/folders` | Crear carpeta |
| POST | `https://teldev.pro/api/projects/{projectId}/files/upload` | Subir archivo |

---

## 🎯 Casos de Uso Comunes

### 1. Usuario pregunta: "¿Cuántos proyectos tengo?"
```
Herramienta: getUserSession
URL: https://teldev.pro/api/chatbot/session?userId={userId}
Respuesta: "Tienes {estadisticas.totalProyectos} proyectos activos"
```

### 2. Usuario pregunta: "¿Tengo tickets pendientes?"
```
Herramienta: getUserTickets
URL: https://teldev.pro/api/chatbot/tickets/user/{userId}
Respuesta: "Tienes {ticketsPendientes} tickets pendientes"
```

### 3. Usuario dice: "Crea un ticket para reportar un bug"
```
Herramienta: createTicket
URL: https://teldev.pro/api/tickets
Body: { asunto, cuerpo, prioridad: 'ALTA', tipo: 'BUG', reportadoPorId }
Respuesta: "Ticket creado con código {codigoTicket}"
```

---

## 🚀 Próximos Pasos

1. ✅ **Actualizar RouteValidationInterceptor** - Completado
2. ✅ **Documentar todos los endpoints** - Completado
3. 🟡 **Configurar herramientas en Flowise** - Pendiente (usar este documento)
4. 🟡 **Implementar autenticación JWT** - Opcional
5. 🟡 **Agregar más herramientas avanzadas** - Futuro

---

## 📞 Soporte

**Documentación Técnica Completa:** Ver `RESUMEN_COMPLETO_API_REST.md`  
**Última Actualización:** 5 de Noviembre, 2025  
**URL del Proyecto:** https://teldev.pro

---

## ⚠️ IMPORTANTE - Respuesta a tu Pregunta

### En el ejemplo que mencionaste:
```javascript
const response = await fetch(`https://tu-dominio.com/api/chatbot/session?userId=${userId}`, {
```

### Debes cambiar la URL a:
```javascript
const response = await fetch(`https://teldev.pro/api/chatbot/session?userId=${userId}`, {
```

**Todas las URLs deben usar:** `https://teldev.pro` como base.

### URLs Correctas para cada herramienta:
- ✅ Sesión: `https://teldev.pro/api/chatbot/session?userId={userId}`
- ✅ Proyectos: `https://teldev.pro/api/chatbot/projects/user/{userId}`
- ✅ Repositorios: `https://teldev.pro/api/chatbot/repositories/user/{userId}`
- ✅ APIs: `https://teldev.pro/api/chatbot/apis/user/{userId}`
- ✅ Tickets: `https://teldev.pro/api/chatbot/tickets/user/{userId}`
- ✅ Crear Ticket: `https://teldev.pro/api/tickets`
- ✅ Crear Conversación: `https://teldev.pro/api/chatbot/conversations`

---

**¡Listo para implementar en Flowise! 🚀**

