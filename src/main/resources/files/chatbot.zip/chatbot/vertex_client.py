import vertexai
from vertexai.preview.generative_models import (
    GenerativeModel,
    Tool,
    FunctionDeclaration,
    Content,
    Part
)
from typing import List, Dict, Any
import os
from config import config
from tools import TelDevTools, TOOL_DEFINITIONS

class VertexChatbot:
    """Cliente para Vertex AI Gemini con Function Calling"""
    
    def __init__(self, project_id: str = None, region: str = None):
        self.project_id = project_id or config.PROJECT_ID
        self.region = region or config.REGION
        
        try:
            # Inicializar Vertex AI
            vertexai.init(project=self.project_id, location=self.region)
            print(f"✅ Vertex AI inicializado: {self.project_id} @ {self.region}")
        except Exception as e:
            print(f"⚠️ Error inicializando Vertex AI: {e}")
            raise
        
        # Crear herramientas de TelDev
        self.teldev_tools = TelDevTools()
        
        # Configurar Function Declarations para Vertex AI
        self.function_declarations = self._create_function_declarations()
        
        # Crear Tool de Vertex AI
        self.vertex_tool = Tool(function_declarations=self.function_declarations)
        
        # Crear modelo con herramientas (SIN system_instruction que causaba error)
        try:
            self.model = GenerativeModel(
                model_name=config.MODEL_NAME,
                tools=[self.vertex_tool],
                generation_config={
                    "temperature": config.TEMPERATURE,
                    "top_p": config.TOP_P,
                    "top_k": config.TOP_K,
                    "max_output_tokens": config.MAX_OUTPUT_TOKENS,
                }
            )
            print(f"✅ Modelo cargado: {config.MODEL_NAME}")
        except Exception as e:
            print(f"⚠️ Error cargando modelo: {e}")
            raise
    
    def _create_function_declarations(self) -> List[FunctionDeclaration]:
        """Convierte las definiciones de herramientas a FunctionDeclaration de Vertex AI"""
        declarations = []
        
        for tool_def in TOOL_DEFINITIONS:
            func_decl = FunctionDeclaration(
                name=tool_def["name"],
                description=tool_def["description"],
                parameters=tool_def["parameters"]
            )
            declarations.append(func_decl)
        
        print(f"✅ {len(declarations)} herramientas cargadas")
        return declarations
    
    def _execute_function(self, function_name: str, function_args: Dict[str, Any]) -> Any:
        """Ejecuta una función de herramienta"""
        print(f"🔧 Ejecutando: {function_name}({function_args})")
        
        # Mapear nombre de función a método de TelDevTools
        method = getattr(self.teldev_tools, function_name, None)
        
        if method is None:
            error_msg = f"Función {function_name} no encontrada"
            print(f"❌ {error_msg}")
            return {"success": False, "error": error_msg}
        
        try:
            result = method(**function_args)
            print(f"✅ Resultado: {result.get('success', False)}")
            return result
        except Exception as e:
            error_msg = f"Error ejecutando {function_name}: {str(e)}"
            print(f"❌ {error_msg}")
            return {"success": False, "error": error_msg}
    
    def send_message(
        self, 
        user_message: str, 
        user_id: int,
        history: List[Content] = None
    ) -> Dict[str, Any]:
        """
        Envía un mensaje al chatbot y maneja Function Calling
        
        Args:
            user_message: Mensaje del usuario
            user_id: ID del usuario para contexto
            history: Historial de conversación
        
        Returns:
            Dict con respuesta del chatbot y metadatos
        """
        if history is None:
            history = []
        
        print(f"📩 Mensaje: {user_message[:50]}... (User: {user_id})")
        
        try:
            # Iniciar chat con historial
            chat = self.model.start_chat(history=history)
            
            # Agregar system prompt y contexto al primer mensaje
            contextualized_message = f"""{config.SYSTEM_PROMPT}

[Usuario ID: {user_id}]
Usuario: {user_message}"""
            
            # Enviar mensaje
            response = chat.send_message(contextualized_message)
            
            # Verificar si hay Function Calls
            function_calls = []
            
            for part in response.candidates[0].content.parts:
                if part.function_call:
                    function_calls.append(part.function_call)
            
            print(f"🔍 Function calls detectados: {len(function_calls)}")
            
            # Si hay Function Calls, ejecutarlas
            if function_calls:
                function_responses = []
                
                for function_call in function_calls:
                    function_name = function_call.name
                    function_args = dict(function_call.args)
                    
                    # Agregar userId automáticamente si la función lo requiere
                    if "userId" in function_args and function_args["userId"] == 0:
                        function_args["userId"] = user_id
                    elif "userId" not in function_args and function_name in [
                        "getUserSession", "listUserProjects", 
                        "listUserRepositories", "listUserTickets"
                    ]:
                        function_args["userId"] = user_id
                    
                    # Ejecutar función
                    result = self._execute_function(function_name, function_args)
                    
                    # Crear respuesta de función
                    function_response = Part.from_function_response(
                        name=function_name,
                        response={"content": result}
                    )
                    function_responses.append(function_response)
                
                # Enviar respuestas de funciones de vuelta al modelo
                response = chat.send_message(function_responses)
            
            # Obtener texto de respuesta final
            response_text = response.text
            print(f"✅ Respuesta generada: {len(response_text)} caracteres")
            
            return {
                "success": True,
                "response": response_text,
                "history": chat.history,
                "function_calls_made": len(function_calls)
            }
        
        except Exception as e:
            error_msg = str(e)
            print(f"❌ Error: {error_msg}")
            return {
                "success": False,
                "error": error_msg,
                "response": "Lo siento, hubo un error al procesar tu mensaje. Por favor, intenta de nuevo."
            }
