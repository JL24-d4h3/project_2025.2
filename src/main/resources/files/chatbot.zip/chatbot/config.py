import os
from typing import Optional

class Config:
    # Google AI Configuration (para gemini_client.py)
    GOOGLE_AI_API_KEY: str = os.getenv("GOOGLE_AI_API_KEY", "")
    
    # GCP Configuration (para vertex_client.py si se usa)
    PROJECT_ID: str = os.getenv("GCP_PROJECT_ID", "api-sandbox-476603")
    REGION: str = os.getenv("GCP_REGION", "us-central1")
    
    # Vertex AI Configuration - MODELO CORRECTO
    MODEL_NAME: str = "gemini-1.5-flash"  # Cambiado de gemini-1.5-pro
    TEMPERATURE: float = 0.7
    MAX_OUTPUT_TOKENS: int = 2048
    TOP_P: float = 0.95
    TOP_K: int = 40
    
    # TelDev API Configuration
    TELDEV_API_URL: str = os.getenv("TELDEV_API_URL", "https://teldev.pro")
    TELDEV_TIMEOUT: int = 30
    
    # Firestore Configuration
    FIRESTORE_COLLECTION: str = "chat_sessions"
    
    # API Configuration
    API_PORT: int = int(os.getenv("PORT", "8080"))
    API_HOST: str = "0.0.0.0"
    
    # System Prompt
    SYSTEM_PROMPT: str = """Eres el asistente inteligente de TelDev Developer Portal, una plataforma que combina gestión de proyectos, repositorios y documentación de APIs.

CAPACIDADES:
- Consultar información de sesión del usuario
- Buscar en documentaciones de APIs
- Listar proyectos y repositorios
- Gestionar tickets (crear, listar, buscar)
- Explorar archivos de repositorios

REGLAS IMPORTANTES:
1. Siempre usa las herramientas disponibles, no inventes información
2. Si necesitas datos del usuario, usa getUserSession primero
3. Para crear tickets, asegúrate de tener asunto y descripción claros
4. Sé conciso pero informativo
5. Si hay error en una operación, explica qué salió mal
6. Formatea las respuestas de manera clara y legible con emojis relevantes

Ejemplo de interacciones:
- "¿Cuántos proyectos tengo?" → Usa getUserSession y responde con el número
- "Crea un ticket de bug" → Pregunta por asunto y descripción antes de crear
- "Muéstrame mis tickets" → Lista los tickets con formato claro
"""

config = Config()
