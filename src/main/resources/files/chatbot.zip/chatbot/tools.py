import requests
from typing import Dict, Any, Optional
from config import config

class TelDevTools:
    """Herramientas para interactuar con la API de TelDev"""
    
    def __init__(self, base_url: str = None):
        self.base_url = base_url or config.TELDEV_API_URL
        self.timeout = config.TELDEV_TIMEOUT
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
    
    def _make_request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Método auxiliar para hacer requests HTTP"""
        url = f"{self.base_url}{endpoint}"
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=self.headers,
                timeout=self.timeout,
                **kwargs
            )
            
            if response.status_code >= 400:
                return {
                    "success": False,
                    "error": f"HTTP {response.status_code}: {response.text[:200]}",
                    "statusCode": response.status_code
                }
            
            return response.json()
        
        except requests.exceptions.Timeout:
            return {"success": False, "error": "Request timeout", "type": "timeout"}
        except requests.exceptions.ConnectionError:
            return {"success": False, "error": "Connection error", "type": "connection_error"}
        except Exception as e:
            return {"success": False, "error": str(e), "type": "unknown_error"}
    
    def getUserSession(self, userId: int) -> Dict[str, Any]:
        """
        Obtiene información completa de la sesión del usuario
        
        Args:
            userId: ID del usuario autenticado
        
        Returns:
            Dict con información del usuario, proyectos, repos, APIs, tickets
        """
        if userId is None or userId <= 0:
            return {"success": False, "error": "Usuario no autenticado"}
        
        data = self._make_request("GET", f"/api/chatbot/session?userId={userId}")
        
        if data.get("success"):
            usuario = data.get("userData", {})
            return {
                "success": True,
                "message": f"✅ Usuario: {usuario.get('nombre', 'N/A')} {usuario.get('apellido', '')}",
                "data": data
            }
        
        return data
    
    def listUserProjects(self, userId: int) -> Dict[str, Any]:
        """
        Lista todos los proyectos del usuario
        
        Args:
            userId: ID del usuario
        
        Returns:
            Dict con lista de proyectos
        """
        if userId is None or userId <= 0:
            return {"success": False, "error": "Usuario no autenticado"}
        
        data = self._make_request("GET", f"/api/chatbot/projects/user/{userId}")
        
        if data.get("success"):
            proyectos = data.get("proyectos", [])
            total = data.get("totalProyectos", 0)
            
            if total == 0:
                mensaje = "📁 No tienes proyectos registrados"
            else:
                lista = "\n".join([
                    f"{i+1}. {p.get('nombreProyecto')} - Estado: {p.get('estadoProyecto')}"
                    for i, p in enumerate(proyectos[:10])
                ])
                mensaje = f"📁 Tienes {total} proyecto(s):\n{lista}"
            
            return {
                "success": True,
                "message": mensaje,
                "totalProyectos": total,
                "proyectos": proyectos
            }
        
        return data
    
    def listUserRepositories(self, userId: int) -> Dict[str, Any]:
        """
        Lista todos los repositorios del usuario
        
        Args:
            userId: ID del usuario
        
        Returns:
            Dict con lista de repositorios
        """
        if userId is None or userId <= 0:
            return {"success": False, "error": "Usuario no autenticado"}
        
        data = self._make_request("GET", f"/api/chatbot/repositories/user/{userId}")
        
        if data.get("success"):
            repositorios = data.get("repositorios", [])
            total = data.get("totalRepositorios", 0)
            
            if total == 0:
                mensaje = "📦 No tienes repositorios registrados"
            else:
                lista = "\n".join([
                    f"{i+1}. {r.get('nombreRepositorio')} ({r.get('proyecto', 'Sin proyecto')})"
                    for i, r in enumerate(repositorios[:10])
                ])
                mensaje = f"📦 Tienes {total} repositorio(s):\n{lista}"
            
            return {
                "success": True,
                "message": mensaje,
                "totalRepositorios": total,
                "repositorios": repositorios
            }
        
        return data
    
    def listUserTickets(self, userId: int) -> Dict[str, Any]:
        """
        Lista todos los tickets del usuario
        
        Args:
            userId: ID del usuario
        
        Returns:
            Dict con lista de tickets
        """
        if userId is None or userId <= 0:
            return {"success": False, "error": "Usuario no autenticado"}
        
        data = self._make_request("GET", f"/api/chatbot/tickets/user/{userId}")
        
        if data.get("success"):
            tickets = data.get("tickets", [])
            total = data.get("totalTickets", 0)
            abiertos = len([t for t in tickets if t.get("estado") == "ABIERTO"])
            
            if total == 0:
                mensaje = "🎫 No tienes tickets registrados"
            else:
                lista = "\n".join([
                    f"{i+1}. {t.get('asunto')} - {t.get('estado')} (Prioridad: {t.get('prioridad')})"
                    for i, t in enumerate(tickets[:10])
                ])
                mensaje = f"🎫 Tienes {total} ticket(s) ({abiertos} abiertos):\n{lista}"
            
            return {
                "success": True,
                "message": mensaje,
                "totalTickets": total,
                "ticketsAbiertos": abiertos,
                "tickets": tickets
            }
        
        return data
    
    def searchApiDocumentation(self) -> Dict[str, Any]:
        """
        Lista todas las APIs disponibles
        
        Returns:
            Dict con lista de APIs
        """
        data = self._make_request("GET", "/api/apis")
        
        if data.get("success"):
            apis = data.get("apis", [])
            total = data.get("totalApis", 0)
            
            if total == 0:
                mensaje = "📚 No hay APIs registradas"
            else:
                lista = "\n".join([
                    f"{i+1}. {api.get('nombreApi')} v{api.get('version', '1.0')} - {api.get('estadoApi', 'N/A')}"
                    for i, api in enumerate(apis[:10])
                ])
                mensaje = f"📚 Hay {total} API(s) disponibles:\n{lista}"
            
            return {
                "success": True,
                "message": mensaje,
                "totalApis": total,
                "apis": apis
            }
        
        return data
    
    def getRepositoryFiles(self, projectId: int, repoId: int) -> Dict[str, Any]:
        """
        Lista archivos de un repositorio específico
        
        Args:
            projectId: ID del proyecto
            repoId: ID del repositorio
        
        Returns:
            Dict con lista de archivos
        """
        if projectId is None or projectId <= 0 or repoId is None or repoId <= 0:
            return {"success": False, "error": "Debe especificar projectId y repoId válidos"}
        
        data = self._make_request("GET", f"/api/projects/{projectId}/repositories/{repoId}/files")
        
        if data.get("success"):
            archivos = data.get("archivos", data.get("nodos", []))
            carpetas = len([a for a in archivos if a.get("tipo") == "CARPETA" or a.get("esCarpeta")])
            files = len(archivos) - carpetas
            
            lista = "\n".join([
                f"{'📁' if a.get('tipo') == 'CARPETA' else '📄'} {a.get('nombre')}"
                for a in archivos[:15]
            ])
            
            mensaje = f"📂 Repositorio:\n- {carpetas} carpeta(s)\n- {files} archivo(s)\n\n{lista}"
            
            return {
                "success": True,
                "message": mensaje,
                "totalArchivos": len(archivos),
                "items": archivos
            }
        
        return data


# Definición de herramientas para Vertex AI Function Calling
TOOL_DEFINITIONS = [
    {
        "name": "getUserSession",
        "description": "Obtiene información completa del usuario actual incluyendo: datos personales, proyectos, repositorios, APIs documentadas, tickets y estadísticas. Usa esto cuando necesites saber información del usuario.",
        "parameters": {
            "type": "object",
            "properties": {
                "userId": {
                    "type": "integer",
                    "description": "ID del usuario autenticado"
                }
            },
            "required": ["userId"]
        }
    },
    {
        "name": "listUserProjects",
        "description": "Lista todos los proyectos en los que participa el usuario actual. Muestra nombre, descripción, estado y rol del usuario en cada proyecto.",
        "parameters": {
            "type": "object",
            "properties": {
                "userId": {
                    "type": "integer",
                    "description": "ID del usuario"
                }
            },
            "required": ["userId"]
        }
    },
    {
        "name": "listUserRepositories",
        "description": "Lista todos los repositorios del usuario. Incluye información sobre commits, ramas y última actividad.",
        "parameters": {
            "type": "object",
            "properties": {
                "userId": {
                    "type": "integer",
                    "description": "ID del usuario"
                }
            },
            "required": ["userId"]
        }
    },
    {
        "name": "listUserTickets",
        "description": "Lista todos los tickets del usuario (reportados y asignados). Muestra estado, prioridad y descripción de cada ticket.",
        "parameters": {
            "type": "object",
            "properties": {
                "userId": {
                    "type": "integer",
                    "description": "ID del usuario"
                }
            },
            "required": ["userId"]
        }
    },
    {
        "name": "searchApiDocumentation",
        "description": "Lista todas las APIs disponibles en el sistema. Muestra nombre, versión y estado de cada API.",
        "parameters": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "getRepositoryFiles",
        "description": "Lista los archivos y carpetas de un repositorio específico. Muestra estructura de directorios.",
        "parameters": {
            "type": "object",
            "properties": {
                "projectId": {
                    "type": "integer",
                    "description": "ID del proyecto"
                },
                "repoId": {
                    "type": "integer",
                    "description": "ID del repositorio"
                }
            },
            "required": ["projectId", "repoId"]
        }
    }
]
