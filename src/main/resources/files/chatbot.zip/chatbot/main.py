from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import logging
import os
from datetime import datetime

from gemini_client import GeminiChatbot

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="TelDev Chatbot API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Inicializar Gemini Chatbot
api_key = os.getenv("GOOGLE_AI_API_KEY")
if not api_key:
    logger.error("❌ GOOGLE_AI_API_KEY no configurada")
    raise ValueError("GOOGLE_AI_API_KEY es requerida")

chatbot = GeminiChatbot(api_key=api_key)
logger.info("✅ Gemini Chatbot inicializado")

class ChatRequest(BaseModel):
    message: str
    userId: int
    sessionId: Optional[str] = None

class ChatResponse(BaseModel):
    response: str
    sessionId: str
    timestamp: str
    success: bool

@app.get("/")
async def root():
    return {"service": "TelDev Chatbot", "status": "running", "version": "1.0.0"}

@app.get("/health")
async def health():
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}

@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    try:
        session_id = request.sessionId or f"session_{request.userId}_{datetime.utcnow().timestamp()}"
        
        # Usar Gemini con Function Calling automático
        result = chatbot.send_message(
            user_message=request.message,
            user_id=request.userId
        )
        
        if not result.get("success"):
            raise HTTPException(
                status_code=500, 
                detail=result.get("error", "Error desconocido")
            )
        
        return ChatResponse(
            response=result["response"],
            sessionId=session_id,
            timestamp=datetime.utcnow().isoformat(),
            success=True
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
