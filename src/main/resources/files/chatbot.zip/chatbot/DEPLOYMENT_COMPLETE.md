# ✅ CHATBOT TELDEV - DEPLOYMENT COMPLETO

## 🎉 Estado: FUNCIONANDO

**Service URL:** https://chatbot-vertex-4epq24vhwa-uc.a.run.app

---

## 📊 Información del Servicio

| Propiedad | Valor |
|-----------|-------|
| **Servicio** | chatbot-vertex |
| **Región** | us-central1 |
| **Memoria** | 1 GB |
| **CPU** | 1 vCPU |
| **Timeout** | 300s |
| **Backend** | https://teldev.pro |

---

## 🔗 Endpoints Disponibles

### Health Check
```bash
GET https://chatbot-vertex-4epq24vhwa-uc.a.run.app/health
```

### Chat
```bash
POST https://chatbot-vertex-4epq24vhwa-uc.a.run.app/chat

Body:
{
  "message": "¿Cuántos proyectos tengo?",
  "userId": 38,
  "sessionId": "optional-session-id"
}
```

---

## 🛠️ Herramientas Integradas

1. ✅ **getUserSession** - Información completa del usuario
2. ✅ **listUserProjects** - Lista de proyectos
3. ✅ **listUserRepositories** - Lista de repositorios
4. ✅ **listUserTickets** - Lista de tickets
5. ✅ **searchApiDocumentation** - APIs disponibles
6. ✅ **getRepositoryFiles** - Archivos de repositorio (requiere projectId y repoId)

---

## 🎯 Comandos de Prueba
```bash
SERVICE_URL="https://chatbot-vertex-4epq24vhwa-uc.a.run.app"

# Saludo
curl -X POST "$SERVICE_URL/chat" \
  -H "Content-Type: application/json" \
  -d '{"message":"Hola","userId":1}'

# Proyectos
curl -X POST "$SERVICE_URL/chat" \
  -H "Content-Type: application/json" \
  -d '{"message":"¿Cuántos proyectos tengo?","userId":38}'

# Repositorios
curl -X POST "$SERVICE_URL/chat" \
  -H "Content-Type: application/json" \
  -d '{"message":"Muéstrame mis repositorios","userId":38}'

# Tickets
curl -X POST "$SERVICE_URL/chat" \
  -H "Content-Type: application/json" \
  -d '{"message":"Lista mis tickets","userId":38}'
```

---

## 📱 Integración con Frontend

### JavaScript/TypeScript
```javascript
import { TelDevChatbot } from './frontend-config';

const chatbot = new TelDevChatbot(userId);
const result = await chatbot.sendMessage("¿Cuántos proyectos tengo?");
console.log(result.response);
```

### cURL
```bash
curl -X POST "https://chatbot-vertex-4epq24vhwa-uc.a.run.app/chat" \
  -H "Content-Type: application/json" \
  -d '{"message":"Hola","userId":38}'
```

---

## 🔧 Comandos de Gestión

### Ver logs
```bash
gcloud run services logs read chatbot-vertex --region us-central1 --limit 50
```

### Logs en tiempo real
```bash
gcloud run services logs tail chatbot-vertex --region us-central1
```

### Redeploy
```bash
cd ~/chatbot-vertex
gcloud builds submit --tag gcr.io/$(gcloud config get-value project)/chatbot-vertex
gcloud run deploy chatbot-vertex --region us-central1
```

### Ver métricas
```bash
gcloud run services describe chatbot-vertex --region us-central1
```

---

## ⚠️ Limitaciones Actuales

- ❌ No usa Vertex AI (versión simplificada con pattern matching)
- ✅ Todas las herramientas funcionan
- ✅ Conectado a teldev.pro
- ✅ Sin historial persistente (cada sesión es independiente)

---

## 🚀 Próximos Pasos (Opcional)

### Para agregar Vertex AI:
1. Actualizar requirements.txt con versión compatible del SDK
2. Modificar main.py para usar VertexChatbot
3. Configurar system_instruction correctamente
4. Rebuild y redeploy

### Para agregar historial:
1. Habilitar Firestore
2. Modificar main.py para guardar conversaciones
3. Redeploy

---

## 💰 Costos Estimados

- **Cloud Run:** ~$5-10/mes (tráfico bajo)
- **Total:** ~$5-10/mes

---

## 📞 Soporte

- **Logs:** https://console.cloud.google.com/run/detail/us-central1/chatbot-vertex
- **Documentación:** Ver README.md en el repositorio

---

**Fecha de deployment:** 2025-11-05
**Versión:** 1.0.0-minimal
**Estado:** ✅ PRODUCCIÓN
