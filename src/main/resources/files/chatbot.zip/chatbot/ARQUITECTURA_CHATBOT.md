# 🏗️ ARQUITECTURA DEL CHATBOT TELDEV
**Fecha:** 6 de Noviembre, 2025  
**Versión:** 1.0  
**Estado:** ✅ Documentación Completa

---

## 📊 ARQUITECTURA ACTUAL

### 🎯 **Flujo Completo**

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│  Usuario en https://teldev.pro/devportal/po/mlopez/chatbot-test│
│                                                                 │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ POST /chat
                         │ { message, userId, sessionId }
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│   Python FastAPI + Vertex AI                                    │
│   https://chatbot-vertex-4epq24vhwa-uc.a.run.app               │
│                                                                 │
│   ┌─────────────────────────────────────────────────────┐     │
│   │ main.py - FastAPI server                             │     │
│   │  ├─ CORS habilitado para teldev.pro                  │     │
│   │  ├─ POST /chat endpoint                              │     │
│   │  └─ GET /health endpoint                             │     │
│   └─────────────────────────────────────────────────────┘     │
│                                                                 │
│   ┌─────────────────────────────────────────────────────┐     │
│   │ vertex_client.py - Cliente de Vertex AI              │     │
│   │  ├─ Gemini 1.5 Pro                                   │     │
│   │  ├─ Function Calling habilitado                      │     │
│   │  └─ System Instructions configuradas                 │     │
│   └─────────────────────────────────────────────────────┘     │
│                                                                 │
│   ┌─────────────────────────────────────────────────────┐     │
│   │ tools.py - Herramientas disponibles                  │     │
│   │  ├─ getUserSession()                                 │     │
│   │  ├─ listUserProjects()                               │     │
│   │  ├─ listUserRepositories()                           │     │
│   │  ├─ listUserTickets()                                │     │
│   │  ├─ searchApiDocumentation()                         │     │
│   │  └─ getRepositoryFiles()                             │     │
│   └─────────────────────────────────────────────────────┘     │
│                                                                 │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ HTTP Requests a:
                         │ https://teldev.pro/api/chatbot/*
                         │ https://teldev.pro/api/tickets/*
                         │ https://teldev.pro/api/apis/*
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│   TelDev Backend API (Spring Boot)                              │
│   https://teldev.pro                                            │
│                                                                 │
│   ├─ ChatbotRestController - /api/chatbot/*                    │
│   ├─ TicketRestController - /api/tickets/*                     │
│   ├─ ApiRestController - /api/apis/*                           │
│   └─ MySQL Database (dev_portal_sql)                           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔑 **COMPONENTES PRINCIPALES**

### 1️⃣ **Frontend (chatbot-test.html)**

**Ubicación:** `src/main/resources/templates/chatbot-test.html`

**Responsabilidades:**
- ✅ Renderizar interfaz de chat personalizada
- ✅ Capturar mensajes del usuario
- ✅ Enviar requests a Python API
- ✅ Mostrar respuestas del chatbot
- ✅ Manejar errores de conexión

**Variables Thymeleaf:**
```javascript
const username = /*[[${username}]]*/ 'usuario';
const nombreCompleto = /*[[${nombreCompleto}]]*/ 'Usuario';
const email = /*[[${email}]]*/ 'email@example.com';
const rol = /*[[${rol}]]*/ 'Usuario';
const userId = /*[[${usuario.usuarioId}]]*/ 0;
```

**Endpoint de Chatbot:**
```javascript
const CHATBOT_API_URL = 'https://chatbot-vertex-4epq24vhwa-uc.a.run.app';
```

**Función principal:**
```javascript
async function sendMessage() {
    const response = await fetch(`${CHATBOT_API_URL}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            message: message,
            userId: userId,
            sessionId: `session_${userId}_${Date.now()}`
        })
    });
    
    const data = await response.json();
    addBotMessage(data.response);
}
```

---

### 2️⃣ **Python API (Cloud Run)**

**Ubicación:** `src/main/resources/files/chatbot/`

**URL Producción:** `https://chatbot-vertex-4epq24vhwa-uc.a.run.app`

#### **Archivos:**

##### `main.py` - FastAPI Server
```python
@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    # Recibe: { message, userId, sessionId }
    # Procesa con Vertex AI
    # Retorna: { response, sessionId, timestamp, success }
```

**CORS configurado:**
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://teldev.pro",
        "https://www.teldev.pro",
        "http://localhost:8080",
        "*"  # Temporal para debug
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

##### `vertex_client.py` - Cliente Vertex AI
- Inicializa Gemini 1.5 Pro
- Configura Function Calling
- Procesa conversaciones
- Ejecuta herramientas automáticamente

##### `tools.py` - Definición de Herramientas
```python
class TelDevTools:
    def getUserSession(self, userId: int) -> Dict[str, Any]:
        # GET https://teldev.pro/api/chatbot/session?userId={userId}
        
    def listUserProjects(self, userId: int) -> Dict[str, Any]:
        # GET https://teldev.pro/api/chatbot/projects/user/{userId}
        
    def listUserRepositories(self, userId: int) -> Dict[str, Any]:
        # GET https://teldev.pro/api/chatbot/repositories/user/{userId}
        
    def listUserTickets(self, userId: int) -> Dict[str, Any]:
        # GET https://teldev.pro/api/chatbot/tickets/user/{userId}
        
    def searchApiDocumentation(self) -> Dict[str, Any]:
        # GET https://teldev.pro/api/apis
        
    def getRepositoryFiles(self, projectId: int, repoId: int) -> Dict[str, Any]:
        # GET https://teldev.pro/api/projects/{projectId}/repositories/{repoId}/files
```

**Definiciones para Vertex AI:**
```python
TOOL_DEFINITIONS = [
    {
        "name": "getUserSession",
        "description": "Obtiene información completa del usuario...",
        "parameters": {
            "type": "object",
            "properties": {
                "userId": {"type": "integer", "description": "ID del usuario"}
            },
            "required": ["userId"]
        }
    },
    # ... más herramientas
]
```

##### `config.py` - Configuración
```python
class Config:
    GCP_PROJECT_ID = "api-sandbox-476603"
    GCP_REGION = "us-central1"
    MODEL_NAME = "gemini-1.5-pro"
    TELDEV_API_URL = "https://teldev.pro"
    
    SYSTEM_PROMPT = """
    Eres el asistente inteligente de TelDev Developer Portal...
    """
```

---

### 3️⃣ **Backend Spring Boot**

**Ubicación:** `src/main/java/org/project/project/`

**URL Producción:** `https://teldev.pro`

#### **Controladores Relevantes:**

##### `ChatbotController.java`
```java
@GetMapping("/devportal/{rol}/{username}/chatbot-test")
public String showChatbotTest(...) {
    // Renderiza chatbot-test.html con datos del usuario
    model.addAttribute("username", username);
    model.addAttribute("email", usuario.getCorreo());
    model.addAttribute("nombreCompleto", usuario.getNombreUsuario());
    model.addAttribute("rol", rolesStr);
    model.addAttribute("usuario", usuario);
}
```

##### `ChatbotRestController.java`
```java
@RestController
@RequestMapping("/api/chatbot")
public class ChatbotRestController {
    
    @GetMapping("/session")
    public ResponseEntity<Map<String, Object>> getUserSession(@RequestParam Long userId) {
        // Retorna: usuario + proyectos + repositorios + apis + tickets + estadísticas
    }
    
    @GetMapping("/projects/user/{userId}")
    public ResponseEntity<Map<String, Object>> getUserProjects(@PathVariable Long userId) {
        // Retorna: lista de proyectos del usuario
    }
    
    @GetMapping("/repositories/user/{userId}")
    public ResponseEntity<Map<String, Object>> getUserRepositories(@PathVariable Long userId) {
        // Retorna: lista de repositorios del usuario
    }
    
    @GetMapping("/tickets/user/{userId}")
    public ResponseEntity<Map<String, Object>> getUserTickets(@PathVariable Long userId) {
        // Retorna: lista de tickets del usuario
    }
}
```

---

## 🔄 **FLUJO DE CONVERSACIÓN**

### **Ejemplo: Usuario pregunta "¿Cuántos proyectos tengo?"**

```
1. Usuario escribe en chat: "¿Cuántos proyectos tengo?"
   ↓
2. JavaScript envía POST a https://chatbot-vertex-4epq24vhwa-uc.a.run.app/chat
   Body: { message: "¿Cuántos proyectos tengo?", userId: 38, sessionId: "..." }
   ↓
3. Python API recibe y envía a Vertex AI Gemini:
   - Mensaje del usuario
   - Context del sistema
   - Herramientas disponibles (TOOL_DEFINITIONS)
   ↓
4. Vertex AI analiza y decide usar herramienta:
   Function: listUserProjects
   Arguments: { userId: 38 }
   ↓
5. Python ejecuta TelDevTools.listUserProjects(38):
   GET https://teldev.pro/api/chatbot/projects/user/38
   ↓
6. Spring Boot ChatbotRestController procesa:
   - Consulta base de datos
   - Retorna JSON con proyectos
   ↓
7. Python recibe respuesta:
   { 
     "success": true,
     "totalProyectos": 5,
     "proyectos": [...]
   }
   ↓
8. Vertex AI genera respuesta en lenguaje natural:
   "Tienes 5 proyectos activos:
   1. Sistema de Pagos - Activo
   2. Portal de Clientes - En Desarrollo
   ..."
   ↓
9. Python retorna a frontend:
   { 
     "response": "Tienes 5 proyectos activos...",
     "sessionId": "...",
     "success": true
   }
   ↓
10. JavaScript muestra respuesta en el chat
```

---

## ❓ **PREGUNTAS FRECUENTES**

### **1. ¿Qué pasaría si cambio la URL del chatbot?**

**Pregunta original del usuario:**
> "¿Qué pasaría si el enlace fuera cualquier otro diferente?"

**Respuesta:**

Si cambias en `chatbot-test.html`:
```javascript
// DE:
const CHATBOT_API_URL = 'https://flowise-teldev-4epg24vhwa-uc.a.run.app';

// A:
const CHATBOT_API_URL = 'https://chatbot-vertex-4epq24vhwa-uc.a.run.app';
```

**Resultado:**
- ✅ **Funcionará** - Porque es tu servicio real
- ✅ **CORS OK** - Ya configurado para `teldev.pro`
- ✅ **Endpoints correctos** - `/chat` y `/health` existen
- ✅ **Vertex AI activo** - Procesará con Gemini 1.5 Pro

**Antes (con Flowise URL):**
- ❌ Error CORS
- ❌ Error 404 (endpoints no existen)
- ❌ No funciona

**Después (con Vertex URL correcta):**
- ✅ Chat funciona
- ✅ Herramientas se ejecutan
- ✅ Usuario recibe respuestas

---

### **2. ¿Por qué salía "email@example.com" en lugar del email real?**

**Causa:** Las variables Thymeleaf no se estaban evaluando correctamente.

**Problema original:**
```javascript
const email = '[[${email}]]';  // Sin comentarios inline
```

**Solución:**
```javascript
const email = /*[[${email}]]*/ 'email@example.com';  // Con valor por defecto
```

**Explicación:**
- Thymeleaf procesa `/*[[${email}]]*/` como comentario JavaScript
- Si `${email}` existe → reemplaza todo con el valor real
- Si `${email}` es null → deja el valor por defecto

---

### **3. ¿Cómo sé que el chatbot está usando Vertex AI correctamente?**

**Verifica en los logs de Cloud Run:**
```bash
gcloud run services logs read chatbot-vertex --region us-central1 --limit 50
```

**Busca:**
- ✅ "Inicializando Vertex AI Chatbot..."
- ✅ "Function calls made: 1" (o más)
- ✅ "Chat request - User: 38, Message: ..."
- ✅ "Response generated"

**Si ves errores:**
- ❌ "Error inicializando Vertex AI" → Problema de credenciales
- ❌ "Failed to fetch" → Problema CORS
- ❌ "HTTP 401" → Problema autenticación

---

## 🚀 **DEPLOY Y MANTENIMIENTO**

### **Redesplegar Python API**
```bash
cd c:\Users\jesus\Desktop\SOLO_TRABAJO\jesusleon\src\main\resources\files\chatbot

# Build
gcloud builds submit --tag gcr.io/api-sandbox-476603/chatbot-vertex

# Deploy
gcloud run deploy chatbot-vertex \
  --region us-central1 \
  --image gcr.io/api-sandbox-476603/chatbot-vertex \
  --platform managed \
  --allow-unauthenticated \
  --set-env-vars GCP_PROJECT_ID=api-sandbox-476603,GCP_REGION=us-central1,TELDEV_API_URL=https://teldev.pro
```

### **Verificar salud del servicio**
```bash
# Health check
curl https://chatbot-vertex-4epq24vhwa-uc.a.run.app/health

# Respuesta esperada:
{
  "status": "healthy",
  "timestamp": "2025-11-06T...",
  "ai_enabled": true
}
```

### **Probar endpoint de chat**
```bash
curl -X POST "https://chatbot-vertex-4epq24vhwa-uc.a.run.app/chat" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Hola",
    "userId": 38,
    "sessionId": "test-session"
  }'
```

---

## 📝 **VARIABLES DE ENTORNO (Cloud Run)**

Configuración actual del servicio:
```bash
GCP_PROJECT_ID=api-sandbox-476603
GCP_REGION=us-central1
TELDEV_API_URL=https://teldev.pro
```

**Ver variables:**
```bash
gcloud run services describe chatbot-vertex \
  --region us-central1 \
  --format="value(spec.template.spec.containers[0].env)"
```

---

## 🔐 **SEGURIDAD**

### **CORS Habilitado Para:**
- ✅ `https://teldev.pro`
- ✅ `https://www.teldev.pro`
- ✅ `http://localhost:8080` (desarrollo)
- ✅ `*` (temporal - REMOVER en producción)

### **Autenticación:**
- Frontend: Session-based (Spring Security)
- Python API: Sin auth (confía en teldev.pro)
- Backend API: Session cookies automáticas

**TODO (Mejoras futuras):**
- [ ] Implementar JWT entre frontend ↔ Python API
- [ ] Validar sessionId en cada request
- [ ] Rate limiting en Python API
- [ ] Logging de conversaciones en Firestore

---

## 📊 **MÉTRICAS Y LOGS**

### **Ver logs en tiempo real:**
```bash
gcloud run services logs tail chatbot-vertex --region us-central1
```

### **Consultar última hora:**
```bash
gcloud run services logs read chatbot-vertex \
  --region us-central1 \
  --limit 100 \
  --format "table(timestamp, severity, textPayload)"
```

### **Dashboard:**
- Consola GCP: https://console.cloud.google.com/run/detail/us-central1/chatbot-vertex
- Métricas: Requests/segundo, latencia, errores
- Costos: ~$5-10/mes (bajo tráfico)

---

## 🎯 **PRÓXIMOS PASOS**

### **Funcionalidades pendientes:**
- [ ] Historial de conversaciones (Firestore)
- [ ] Crear tickets desde el chat
- [ ] Búsqueda en documentación
- [ ] Explorar archivos de repositorios
- [ ] Sugerencias proactivas
- [ ] Modo voz (speech-to-text)

### **Optimizaciones:**
- [ ] Cache de respuestas frecuentes
- [ ] Streaming de respuestas (Server-Sent Events)
- [ ] Compresión de requests
- [ ] CDN para assets

---

## 📞 **SOPORTE**

**Documentos relacionados:**
- `DEPLOYMENT_COMPLETE.md` - Guía de deployment
- `ENDPOINTS_CHATBOT_FLOWISE.md` - Endpoints del backend (SI USARAS FLOWISE)
- `README.md` - Información general

**Contacto:**
- Email: soporte@teldev.pro
- Documentación: https://teldev.pro/docs

---

**Última actualización:** 6 de Noviembre, 2025  
**Versión:** 1.0.0  
**Estado:** ✅ Producción Activa
