import google.generativeai as genai
from typing import Dict, Any
import json
from config import config
from tools import TelDevTools, TOOL_DEFINITIONS

class GeminiChatbot:
    """Cliente para Google AI Gemini con Function Calling"""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        genai.configure(api_key=api_key)
        print(f"✅ Google AI configurado")
        
        self.teldev_tools = TelDevTools()
        self.gemini_functions = self._create_function_declarations()
        
        try:
            self.model = genai.GenerativeModel(
                model_name='gemini-1.5-flash',
                tools=[self.gemini_functions]
            )
            print(f"✅ Modelo Gemini 1.5 Flash cargado")
        except Exception as e:
            print(f"⚠️ Error cargando modelo: {e}")
            raise
    
    def _create_function_declarations(self):
        """Crear declaraciones de funciones para Gemini"""
        functions = []
        
        for tool_def in TOOL_DEFINITIONS:
            functions.append(
                genai.protos.FunctionDeclaration(
                    name=tool_def['name'],
                    description=tool_def['description'],
                    parameters=genai.protos.Schema(
                        type=genai.protos.Type.OBJECT,
                        properties={
                            name: genai.protos.Schema(
                                type=self._get_type(prop.get('type', 'string')),
                                description=prop.get('description', '')
                            )
                            for name, prop in tool_def['parameters'].get('properties', {}).items()
                        },
                        required=tool_def['parameters'].get('required', [])
                    )
                )
            )
        
        print(f"✅ {len(functions)} funciones configuradas")
        return functions
    
    def _get_type(self, type_str: str):
        """Convertir tipo de string a tipo de Gemini"""
        type_map = {
            'string': genai.protos.Type.STRING,
            'integer': genai.protos.Type.INTEGER,
            'number': genai.protos.Type.NUMBER,
            'boolean': genai.protos.Type.BOOLEAN,
            'array': genai.protos.Type.ARRAY,
            'object': genai.protos.Type.OBJECT
        }
        return type_map.get(type_str, genai.protos.Type.STRING)
    
    def _execute_function(self, function_name: str, function_args: Dict[str, Any]) -> Any:
        """Ejecutar función de herramienta"""
        print(f"🔧 Ejecutando: {function_name}({function_args})")
        
        method = getattr(self.teldev_tools, function_name, None)
        
        if method is None:
            return {"success": False, "error": f"Función {function_name} no encontrada"}
        
        try:
            result = method(**function_args)
            print(f"✅ Resultado OK")
            return result
        except Exception as e:
            print(f"❌ Error: {e}")
            return {"success": False, "error": str(e)}
    
    def send_message(self, user_message: str, user_id: int) -> Dict[str, Any]:
        """Enviar mensaje al chatbot"""
        print(f"📩 Mensaje: {user_message[:50]}... (User: {user_id})")
        
        try:
            chat = self.model.start_chat(enable_automatic_function_calling=True)
            
            # Mensaje con contexto
            full_message = f"""{config.SYSTEM_PROMPT}

[Usuario ID: {user_id}]
{user_message}"""
            
            # Enviar mensaje
            response = chat.send_message(full_message)
            
            # Contar function calls
            function_calls_made = 0
            for content in chat.history:
                for part in content.parts:
                    if hasattr(part, 'function_call'):
                        function_calls_made += 1
            
            response_text = response.text
            print(f"✅ Respuesta: {len(response_text)} chars, {function_calls_made} function calls")
            
            return {
                "success": True,
                "response": response_text,
                "function_calls_made": function_calls_made
            }
        
        except Exception as e:
            error_msg = str(e)
            print(f"❌ Error: {error_msg}")
            return {
                "success": False,
                "error": error_msg,
                "response": "Lo siento, hubo un error al procesar tu mensaje."
            }
