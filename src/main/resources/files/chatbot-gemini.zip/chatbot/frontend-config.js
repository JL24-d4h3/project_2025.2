// ========================================
// CONFIGURACIÓN DEL CHATBOT - TELDEV
// ========================================

export const CHATBOT_CONFIG = {
  apiUrl: 'https://chatbot-vertex-4epq24vhwa-uc.a.run.app',
  endpoints: {
    chat: '/chat',
    health: '/health'
  }
};

// ========================================
// CLASE PARA INTEGRACIÓN
// ========================================

export class TelDevChatbot {
  constructor(userId) {
    this.userId = userId;
    this.sessionId = null;
    this.apiUrl = CHATBOT_CONFIG.apiUrl;
  }

  /**
   * Envía un mensaje al chatbot
   */
  async sendMessage(message) {
    try {
      const response = await fetch(`${this.apiUrl}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: message,
          userId: this.userId,
          sessionId: this.sessionId
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      // Guardar sessionId para mantener contexto
      if (data.sessionId) {
        this.sessionId = data.sessionId;
      }

      return {
        success: true,
        response: data.response,
        sessionId: data.sessionId,
        timestamp: data.timestamp
      };

    } catch (error) {
      console.error('Error al enviar mensaje:', error);
      return {
        success: false,
        error: error.message,
        response: 'Lo siento, hubo un error al procesar tu mensaje.'
      };
    }
  }

  /**
   * Inicia una nueva sesión
   */
  newSession() {
    this.sessionId = null;
  }

  /**
   * Verifica el estado del servicio
   */
  async checkHealth() {
    try {
      const response = await fetch(`${this.apiUrl}/health`);
      return await response.json();
    } catch (error) {
      console.error('Error al verificar health:', error);
      return { status: 'unhealthy' };
    }
  }
}

// ========================================
// EJEMPLO DE USO EN REACT
// ========================================

/*
import { TelDevChatbot } from './frontend-config';
import { useState, useEffect } from 'react';

function ChatComponent({ userId }) {
  const [chatbot, setChatbot] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setChatbot(new TelDevChatbot(userId));
  }, [userId]);

  const handleSendMessage = async () => {
    if (!input.trim() || !chatbot) return;

    const userMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const result = await chatbot.sendMessage(input);
      const botMessage = { 
        role: 'assistant', 
        content: result.response 
      };
      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="chat-container">
      <div className="messages">
        {messages.map((msg, idx) => (
          <div key={idx} className={`message ${msg.role}`}>
            {msg.content}
          </div>
        ))}
      </div>
      
      <div className="input-area">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
          placeholder="Escribe tu mensaje..."
        />
        <button onClick={handleSendMessage} disabled={loading}>
          Enviar
        </button>
      </div>
    </div>
  );
}
*/

// ========================================
// EJEMPLO DE USO EN VANILLA JS
// ========================================

/*
const chatbot = new TelDevChatbot(38);

async function sendMessage() {
  const input = document.getElementById('chatInput').value;
  
  // Mostrar mensaje del usuario
  addMessageToUI('user', input);
  
  // Enviar al chatbot
  const result = await chatbot.sendMessage(input);
  
  // Mostrar respuesta del bot
  addMessageToUI('bot', result.response);
  
  // Limpiar input
  document.getElementById('chatInput').value = '';
}

function addMessageToUI(role, content) {
  const messagesDiv = document.getElementById('messages');
  const messageDiv = document.createElement('div');
  messageDiv.className = `message ${role}`;
  messageDiv.textContent = content;
  messagesDiv.appendChild(messageDiv);
  messagesDiv.scrollTop = messagesDiv.scrollHeight;
}
*/
